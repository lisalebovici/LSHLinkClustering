An implementation of locality-sensitive hashing for agglomerative hierarchical clustering (Koga, Ishibashi, Watanbe - 2006)

To download, please run pip install --index-url https://test.pypi.org/simple/ lshlink